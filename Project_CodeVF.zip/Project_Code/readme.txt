--- README --- 

Dans ce readme, vous trouverez les différentes étapes pour pouvoir lancer les différents codes des différentes sections et visualiser les resultats retournés.

Les sources des données sont egalement precisés avec les étapes de pre processing.

I - Dezipez chacun des fichiers .zip


SECTION ---  AlexNet _ ResNet

Dans le dossier " Alexnet_Resnet ", vous trouverez les fichiers matlab (AlexnetScript.m,...) qui répresentent chacun un code du modèle dont le nom se trouve dans le nom du fichier.

Avant de lancer les codes matlab, assurez vous d'avoir installer (AlexNet, ResNet18, ResNet50 et ResNet101) dans votre version de Matlab (R2019a ou plus).

1- Téléchargez le Dataset utilisé depuis ce lien : http://bit.ly/DataToUse, dezipez le et 
 
    placez le dans le dossier  "AlexNet _ ResNet"

2- Ouvrez le fichier .m du modèle dont vous souhaitez visualiser les résultats

3- Lancez le fichier et admirez l'oeuvre d'art !!!


SECTION --- PCASVM

Dans le dossier PCASVM, vous trouverez les fichiers nécessaires utilisé pour faire tourner le code, merci de suivre les étapes ci-après :

1- Téléchargez le Dataset utilisé depuis ce lien : http://bit.ly/SVMdata, dézipez le et 
 
    placez le dans le dossier  "PCASVM"

2- Ouvrez et lancez le fichier pcasvm.m à partir de Matlab 

3- Patientez et observer les résultats à travers la console.



SECTION --- Pre processing

Ne lisez cette section que si vous souhaitez génerer une base de données d'images issue de la base de données d'origine contenant 112120 images.

1- Base de données d'origine  https://nihcc.app.box.com/v/ChestXray-NIHCC/folder/36938765345

2- Télécharger les images et dézipez les .rar dans un même dossier 'images'

3- Copier ce dossier 'images' dans le dossier PreProcessing 

4- Lancez un des fichiers sample_resnet (pour ResNet ou Alexnet) ou sample_pcasvm (pour PCASVM)

5- Vous aurez un dossier 'images_out' qui se creera et constituera votre dataBase que vous pouvez utiliser pour lancer 
     
   le code pcasvm.m (si vous avez utilisé sample_pcasvm ) ou les codes resnet et alexnet (si vous avez utilisé sample_resnet )






